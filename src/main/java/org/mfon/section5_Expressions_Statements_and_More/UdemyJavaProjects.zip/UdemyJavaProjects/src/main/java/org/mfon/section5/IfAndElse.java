package org.mfon.section5;

public class IfAndElse {
    public static void main(String[] args) {
        System.out.print("Hello, Mfon");
    }
}
