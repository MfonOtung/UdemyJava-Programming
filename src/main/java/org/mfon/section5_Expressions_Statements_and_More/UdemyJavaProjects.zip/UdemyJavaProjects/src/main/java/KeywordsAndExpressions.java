public class KeywordsAndExpressions {
    public static void main(String[] args) {
        int myVar = 50;
        myVar++;
        myVar--;
        int anotherVar = 50;
        myVar--;
        System.out.println("myVar = " + myVar);


    }
}
